// Copyright (c) 2000-2001 Quadralay Corporation.  All rights reserved.
//

// Load book data
//
WWHFrame.WWHHelp.mBooks.fInit_AddBook(WWHBookData_Title(),
                                      WWHBookData_Context(),
                                      WWHBookData_Files,
                                      WWHBookData_Popups);

// Increment mInitIndex
//
WWHFrame.WWHHelp.mBooks.fInit_IncrementIndex();
