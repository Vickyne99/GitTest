// Copyright (c) 2000-2001 Quadralay Corporation.  All rights reserved.
//

// Match topic
//
WWHFrame.WWHHelp.fProcessTopicResult(WWHBookData_MatchTopic(WWHFrame.WWHHelp.mTopicTag));
