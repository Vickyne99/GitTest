// Copyright (c) 2000-2001 Quadralay Corporation.  All rights reserved.
//

// Search
//
WWHFrame.WWHSearch.fCheckForMatch(BookData_Search);
